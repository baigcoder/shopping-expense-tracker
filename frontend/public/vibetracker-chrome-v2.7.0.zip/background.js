// Background Service Worker - Enhanced Extension Logic
// Handles auto-detection, sync, notifications, and website communication

// ================================
// SUPABASE CONFIGURATION
// ================================
const SUPABASE_URL = 'https://ebfolvhqjvavrwrfcbhn.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImViZm9sdmhxanZhdnJ3cmZjYmhuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzM2NjI0NDgsImV4cCI6MjA0OTIzODQ0OH0.RC7d0vMx1F4Z2J2Ovl9m2hZV8HCmZ2f6pBWSN-GJ3O0';

const WEBSITE_ORIGINS = [
    'http://localhost:5173',
    'http://localhost:3000',
    'https://vibe-tracker-expense-genz.vercel.app' // Production URL
];

// ================================
// MESSAGE HANDLERS
// ================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Background received:', message.type);

    switch (message.type) {
        case 'PURCHASE_DETECTED':
            handlePurchaseDetected(message.data);
            break;

        case 'TRANSACTION_SYNCED':
            showNotification(message.data);
            break;

        case 'USER_LOGGED_IN':
            handleUserLoggedIn(message.data);
            break;

        case 'USER_LOGGED_OUT':
            handleUserLoggedOut();
            break;

        case 'WEBSITE_LOGIN':
            // Website notifying extension of login
            handleWebsiteLogin(message.data);
            break;

        case 'SUBSCRIPTION_DETECTED':
            handleSubscriptionDetected(message.data);
            break;

        case 'CHECK_EXTENSION_STATUS':
            // Website checking if extension is installed and logged in
            handleExtensionStatusCheck(sendResponse);
            return true; // Keep channel open for async response

        case 'SYNC_SESSION_FROM_WEBSITE':
            // Website sharing session with extension
            handleSessionSync(message.data, sendResponse);
            return true;

        case 'DARK_PATTERN_DETECTED':
            // Dark pattern detector found something
            handleDarkPatternDetected(message.data);
            break;

        case 'SET_TRIAL_REMINDER':
            // User wants a reminder before trial ends
            setTrialReminder(message.data, sendResponse);
            return true;

        case 'GET_PROTECTION_STATS':
            // Get dark pattern protection statistics
            getProtectionStats(sendResponse);
            return true;

        case 'CHECK_AND_LOGOUT_IF_NEEDED':
            // Website has no session - if we synced from website, logout
            checkAndLogoutIfNeeded();
            break;
    }

    sendResponse({ received: true });
    return true;
});

// ================================
// EXTERNAL MESSAGE HANDLER (from website)
// ================================
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    console.log('External message from:', sender.origin, message.type);

    // Verify the sender is our website
    if (!WEBSITE_ORIGINS.some(origin => sender.origin?.includes(origin) || sender.url?.includes(origin))) {
        console.log('Rejected message from unknown origin');
        sendResponse({ error: 'Unknown origin' });
        return;
    }

    switch (message.type) {
        case 'CHECK_EXTENSION':
            // Website checking if extension is installed
            sendResponse({
                installed: true,
                version: chrome.runtime.getManifest().version
            });
            break;

        case 'SYNC_SESSION':
            // Website sending session to extension
            handleSessionSync(message.data, sendResponse);
            return true;

        case 'GET_EXTENSION_STATUS':
            handleExtensionStatusCheck(sendResponse);
            return true;

        case 'WEBSITE_USER_LOGGED_IN':
            // Auto-login extension when website logs in
            handleWebsiteLogin(message.data);
            sendResponse({ success: true });
            break;

        case 'WEBSITE_USER_LOGGED_OUT':
            handleUserLoggedOut();
            sendResponse({ success: true });
            break;
    }
});

// ================================
// SESSION SYNC HANDLERS
// ================================
async function handleSessionSync(data, sendResponse) {
    try {
        if (data.session && data.user) {
            await chrome.storage.local.set({
                supabaseSession: data.session,
                accessToken: data.session.access_token,
                userId: data.user.id,
                userEmail: data.user.email,
                userName: data.user.user_metadata?.name || data.user.email.split('@')[0],
                syncedFromWebsite: true,
                lastSync: Date.now()
            });

            console.log('✅ Session synced from website:', data.user.email);

            // Show sync notification
            showSyncNotification(data.user.email);

            // Sync pending transactions
            await syncPendingTransactions();

            // Notify popup to refresh
            chrome.runtime.sendMessage({ type: 'SESSION_UPDATED' });

            sendResponse({ success: true, message: 'Session synced' });
        } else {
            sendResponse({ success: false, message: 'Invalid session data' });
        }
    } catch (error) {
        console.error('Session sync error:', error);
        sendResponse({ success: false, error: error.message });
    }
}

async function handleExtensionStatusCheck(sendResponse) {
    try {
        const data = await chrome.storage.local.get(['accessToken', 'userEmail', 'userId', 'lastSync']);

        sendResponse({
            installed: true,
            version: chrome.runtime.getManifest().version,
            loggedIn: !!(data.accessToken && data.userEmail),
            userEmail: data.userEmail || null,
            lastSync: data.lastSync || null
        });
    } catch (error) {
        sendResponse({
            installed: true,
            loggedIn: false,
            error: error.message
        });
    }
}

async function handleWebsiteLogin(data) {
    try {
        await chrome.storage.local.set({
            supabaseSession: data.session,
            accessToken: data.session?.access_token || data.accessToken,
            userId: data.user?.id || data.userId,
            userEmail: data.user?.email || data.email,
            userName: data.user?.user_metadata?.name || data.name || data.email?.split('@')[0],
            syncedFromWebsite: true,
            lastSync: Date.now()
        });

        console.log('✅ Auto-logged in from website');

        // Show sync notification
        showSyncNotification(data.user?.email || data.email);

        // Sync pending transactions
        await syncPendingTransactions();

        // Notify popup
        chrome.runtime.sendMessage({ type: 'SESSION_UPDATED' });

        // Notify all website tabs that extension is now synced
        notifyWebsiteTabs('EXTENSION_SYNCED', {
            email: data.user?.email || data.email,
            userId: data.user?.id || data.userId
        });

    } catch (error) {
        console.error('Website login sync error:', error);
    }
}

async function handleUserLoggedIn(data) {
    console.log('User logged in via extension:', data.email);

    // Sync pending transactions
    await syncPendingTransactions();

    // Notify website tabs that extension is now logged in
    notifyWebsiteTabs('EXTENSION_SYNCED', {
        email: data.email,
        userId: data.userId
    });

    // Show notification
    showSyncNotification(data.email);
}

async function handleUserLoggedOut() {
    console.log('🚪 User logged out - clearing all session data');

    // Clear ALL user-related data from storage
    await chrome.storage.local.remove([
        'supabaseSession', 'accessToken', 'userId', 'userEmail',
        'userName', 'syncedFromWebsite', 'lastSync',
        'pendingSync', 'pendingTransactions', 'pendingSubscriptions'
    ]);

    // CRITICAL: Notify popup to refresh and show login view
    try {
        chrome.runtime.sendMessage({ type: 'SESSION_UPDATED' });
        chrome.runtime.sendMessage({ type: 'USER_LOGGED_OUT' });
    } catch (e) {
        // Popup might not be open, that's fine
    }

    // Notify website tabs
    notifyWebsiteTabs('EXTENSION_LOGGED_OUT', {});

    // Show logout notification
    try {
        chrome.notifications.create(`logout-${Date.now()}`, {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: '👋 Logged Out',
            message: 'You have been signed out of Vibe Tracker extension.',
            priority: 2
        });
    } catch (error) {
        console.log('Logout notification error:', error);
    }

    console.log('✅ All session data cleared');
}

// Check if extension was synced from website and website is now logged out
async function checkAndLogoutIfNeeded() {
    try {
        const data = await chrome.storage.local.get(['syncedFromWebsite', 'accessToken']);

        // If we synced from website and website has no session, logout extension too
        if (data.syncedFromWebsite && data.accessToken) {
            console.log('📋 Website session gone, but extension still has session from website sync');
            await handleUserLoggedOut();
        }
    } catch (e) {
        console.log('Check logout error:', e);
    }
}

// ================================
// PURCHASE DETECTION HANDLER
// ================================
async function handlePurchaseDetected(data) {
    console.log('🛒 Purchase detected:', data);

    const authData = await chrome.storage.local.get(['accessToken', 'userId', 'userEmail']);

    if (!authData.accessToken || !authData.userId) {
        console.log('Not logged in, storing for later sync');
        const pending = await chrome.storage.local.get(['pendingTransactions']) || { pendingTransactions: [] };
        pending.pendingTransactions = pending.pendingTransactions || [];
        pending.pendingTransactions.push({
            ...data,
            timestamp: Date.now()
        });
        await chrome.storage.local.set({ pendingTransactions: pending.pendingTransactions });
        return { success: false, pending: true };
    }

    try {
        // Create transaction in Supabase
        const transactionData = {
            user_id: authData.userId,
            description: data.name || data.serviceName || 'Purchase',
            amount: data.price || data.amount || 0,
            type: 'expense',
            category: data.category || 'Shopping',
            date: new Date().toISOString().split('T')[0],
            source: 'extension',
            notes: `Auto-tracked from ${data.hostname || 'web'}`
        };

        const response = await fetch(`${SUPABASE_URL}/rest/v1/transactions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': `Bearer ${authData.accessToken}`,
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(transactionData)
        });

        if (response.ok) {
            const created = await response.json();
            console.log('✅ Transaction saved:', created);

            // Show notification
            showPurchaseNotification(data);

            // Notify website to refresh
            notifyWebsiteTabs('TRANSACTION_ADDED', {
                transaction: created,
                name: data.name,
                amount: data.price || data.amount
            });

            return { success: true };
        } else {
            const error = await response.text();
            console.error('Failed to save transaction:', error);
            return { success: false, error };
        }
    } catch (error) {
        console.error('Transaction save error:', error);
        return { success: false, error: error.message };
    }
}

function showPurchaseNotification(data) {
    const notificationId = `purchase-${Date.now()}`;
    const amount = data.price || data.amount || 0;

    try {
        chrome.notifications.create(notificationId, {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: '🛒 Purchase Tracked!',
            message: `${data.name || 'Purchase'} - $${amount.toFixed(2)}`,
            priority: 2
        });

        setTimeout(() => {
            chrome.notifications.clear(notificationId);
        }, 6000);
    } catch (error) {
        console.log('Purchase notification error:', error);
    }
}

// ================================
// SUBSCRIPTION DETECTION HANDLER
// ================================
async function handleSubscriptionDetected(data) {
    console.log('🔔 Subscription detected:', data);

    const authData = await chrome.storage.local.get(['accessToken', 'userId', 'userEmail']);

    if (!authData.accessToken || !authData.userId) {
        console.log('Not logged in, storing for later sync');
        // Store pending subscription
        const pending = await chrome.storage.local.get(['pendingSubscriptions']) || { pendingSubscriptions: [] };
        pending.pendingSubscriptions = pending.pendingSubscriptions || [];
        pending.pendingSubscriptions.push({
            ...data,
            timestamp: Date.now()
        });
        await chrome.storage.local.set({ pendingSubscriptions: pending.pendingSubscriptions });
        return;
    }

    try {
        // Calculate trial end date
        const today = new Date();
        let trialEndDate = null;
        let trialStartDate = null;

        // Handle both camelCase (from content.js) and snake_case field names
        const isTrial = data.isTrial || data.is_trial || false;
        const trialDays = data.trialDays || data.trial_days || 0;

        if (isTrial && trialDays > 0) {
            trialStartDate = today.toISOString().split('T')[0];
            const endDate = new Date(today);
            endDate.setDate(endDate.getDate() + trialDays);
            trialEndDate = endDate.toISOString().split('T')[0];
        }

        // Create subscription in Supabase
        const billingCycle = data.billingCycle || data.cycle || 'monthly';

        // Calculate next payment date based on billing cycle
        let nextPaymentDate = null;
        if (!isTrial) {
            const nextDate = new Date(today);
            if (billingCycle === 'yearly') {
                nextDate.setFullYear(nextDate.getFullYear() + 1);
            } else if (billingCycle === 'weekly') {
                nextDate.setDate(nextDate.getDate() + 7);
            } else {
                nextDate.setMonth(nextDate.getMonth() + 1);
            }
            nextPaymentDate = nextDate.toISOString().split('T')[0];
        }

        const subscriptionData = {
            user_id: authData.userId,
            name: data.name || data.serviceName || 'Unknown',
            logo: data.logo || data.icon || '📦',
            category: data.category || 'Other',
            price: data.price || data.amount || 0,
            cycle: billingCycle,
            color: data.color || '#6366F1',
            is_active: true,
            is_trial: isTrial,
            status: isTrial ? 'trial' : 'active',
            trial_start_date: trialStartDate,
            trial_end_date: trialEndDate,
            trial_days: trialDays,
            start_date: today.toISOString().split('T')[0],
            next_payment_date: nextPaymentDate,
            source_url: data.sourceUrl || null
        };

        const response = await fetch(`${SUPABASE_URL}/rest/v1/subscriptions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': `Bearer ${authData.accessToken}`,
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(subscriptionData)
        });

        if (response.ok) {
            const created = await response.json();
            console.log('✅ Subscription saved:', created);

            // Show notification
            showSubscriptionNotification(data);

            // Notify website to refresh subscriptions
            notifyWebsiteTabs('SUBSCRIPTION_ADDED', {
                subscription: created,
                name: data.name,
                is_trial: data.is_trial,
                trial_days: data.trial_days
            });
        } else {
            const error = await response.text();
            console.error('Failed to save subscription:', error);
        }
    } catch (error) {
        console.error('Subscription save error:', error);
    }
}

function showSubscriptionNotification(data) {
    const notificationId = `sub-${Date.now()}`;
    const isTrial = data.isTrial || data.is_trial || false;
    const trialDays = data.trialDays || data.trial_days || 0;
    const name = data.name || data.serviceName || 'Subscription';

    try {
        chrome.notifications.create(notificationId, {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: isTrial ? '⏰ Trial Started!' : '📦 Subscription Added!',
            message: isTrial
                ? `${name} - ${trialDays} days free trial. We'll remind you before it ends!`
                : `${name} - Now tracking your subscription.`,
            priority: 2
        });

        setTimeout(() => {
            chrome.notifications.clear(notificationId);
        }, 8000);
    } catch (error) {
        console.log('Subscription notification error:', error);
    }
}

// ================================
// WEBSITE TAB COMMUNICATION
// ================================
async function notifyWebsiteTabs(messageType, data) {
    try {
        const tabs = await chrome.tabs.query({});

        for (const tab of tabs) {
            // Only message tabs with valid URLs that match our origins
            if (tab.id && tab.url && WEBSITE_ORIGINS.some(origin => tab.url.startsWith(origin))) {
                // Use a separate try-catch for each tab to prevent one failure from stopping others
                chrome.tabs.sendMessage(tab.id, {
                    type: messageType,
                    data: data,
                    source: 'extension'
                }).then(() => {
                    console.log('Notified website tab:', tab.id);
                }).catch(() => {
                    // Silently ignore - tab might not have content script loaded yet
                });
            }
        }
    } catch (error) {
        // Silently handle - this is not critical
    }
}

// Safe message sender that doesn't throw
function safeSendMessage(tabId, message) {
    if (!tabId) return Promise.resolve();

    return new Promise((resolve) => {
        try {
            chrome.tabs.sendMessage(tabId, message, (response) => {
                // Clear any error from chrome.runtime.lastError
                if (chrome.runtime.lastError) {
                    // Expected when content script isn't loaded
                }
                resolve(response);
            });
        } catch (e) {
            resolve();
        }
    });
}

// ================================
// PURCHASE DETECTION
// ================================
async function handlePurchaseDetected(data) {
    console.log('🛒 Purchase detected:', data);

    try {
        const authData = await chrome.storage.local.get(['accessToken', 'userId', 'userEmail']);

        const transaction = {
            id: Date.now().toString(),
            store: data.storeName,
            product: data.productName,
            amount: data.amount,
            storeUrl: data.storeUrl,
            date: data.detectedAt || new Date().toISOString(),
            synced: false,
            icon: getCategoryIcon(data.storeName)
        };

        // Save locally first
        const storage = await chrome.storage.local.get(['recentTransactions', 'monthlySpent', 'transactionCount', 'pendingSync']);
        const transactions = storage.recentTransactions || [];
        const pendingSync = storage.pendingSync || [];

        transactions.unshift(transaction);

        await chrome.storage.local.set({
            recentTransactions: transactions.slice(0, 100),
            monthlySpent: (storage.monthlySpent || 0) + transaction.amount,
            transactionCount: (storage.transactionCount || 0) + 1
        });

        // Sync to Supabase if logged in
        if (authData.accessToken && authData.userId) {
            try {
                const response = await fetch(`${SUPABASE_URL}/rest/v1/transactions`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'apikey': SUPABASE_ANON_KEY,
                        'Authorization': `Bearer ${authData.accessToken}`,
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        user_id: authData.userId,
                        description: `${transaction.store} - ${transaction.product}`,
                        amount: transaction.amount,
                        type: 'expense',
                        category: getCategoryFromStore(transaction.store),
                        source: 'extension',
                        date: new Date().toISOString().split('T')[0]
                    })
                });

                if (response.ok) {
                    const result = await response.json();
                    transaction.synced = true;
                    console.log('✅ Transaction synced to Supabase!', result);

                    showNotification(transaction);
                    chrome.runtime.sendMessage({ type: 'TRANSACTION_ADDED' });

                    // Notify website to refresh
                    notifyWebsiteTabs('NEW_TRANSACTION', transaction);
                } else {
                    pendingSync.push(transaction);
                    await chrome.storage.local.set({ pendingSync });
                }
            } catch (syncError) {
                console.error('Sync error:', syncError);
                pendingSync.push(transaction);
                await chrome.storage.local.set({ pendingSync });
            }
        } else {
            pendingSync.push(transaction);
            await chrome.storage.local.set({ pendingSync });
            showNotification(transaction);
        }

    } catch (error) {
        console.error('Handle purchase error:', error);
    }
}

// ================================
// PENDING SYNC
// ================================
async function syncPendingTransactions() {
    try {
        const storage = await chrome.storage.local.get(['pendingSync', 'accessToken', 'userId']);
        const pending = storage.pendingSync || [];

        if (pending.length === 0 || !storage.accessToken || !storage.userId) return;

        console.log(`⏳ Syncing ${pending.length} pending transactions...`);

        const synced = [];
        const failed = [];

        for (const transaction of pending) {
            try {
                const response = await fetch(`${SUPABASE_URL}/rest/v1/transactions`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'apikey': SUPABASE_ANON_KEY,
                        'Authorization': `Bearer ${storage.accessToken}`,
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        user_id: storage.userId,
                        description: `${transaction.store} - ${transaction.product}`,
                        amount: transaction.amount,
                        type: 'expense',
                        category: getCategoryFromStore(transaction.store),
                        source: 'extension',
                        date: transaction.date ? transaction.date.split('T')[0] : new Date().toISOString().split('T')[0]
                    })
                });

                if (response.ok) {
                    synced.push(transaction.id);
                } else {
                    failed.push(transaction);
                }
            } catch (error) {
                failed.push(transaction);
            }
        }

        await chrome.storage.local.set({ pendingSync: failed });

        if (synced.length > 0) {
            console.log(`✅ Synced ${synced.length} transactions`);
            showNotification({
                store: 'Sync Complete',
                product: `${synced.length} transactions synced`,
                amount: 0
            }, true);

            // Notify website
            notifyWebsiteTabs('TRANSACTIONS_SYNCED', { count: synced.length });
        }

    } catch (error) {
        console.error('Pending sync error:', error);
    }
}

// ================================
// NOTIFICATIONS
// ================================
function showNotification(transaction, isSync = false) {
    const notificationId = `expense-${Date.now()}`;

    try {
        chrome.notifications.create(notificationId, {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: isSync ? '✓ Vibe Tracker Synced' : '💸 Purchase Tracked!',
            message: isSync
                ? transaction.product
                : `${transaction.store}: Rs ${transaction.amount?.toFixed(0) || '0'} - ${(transaction.product || '').slice(0, 30)}`,
            priority: 2
        });

        setTimeout(() => {
            chrome.notifications.clear(notificationId);
        }, 5000);
    } catch (error) {
        console.log('Notification error:', error);
    }
}

function showSyncNotification(email) {
    const notificationId = `sync-${Date.now()}`;

    try {
        chrome.notifications.create(notificationId, {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: '🔗 Extension Synced!',
            message: `Connected to ${email}. Auto-tracking is now active.`,
            priority: 2
        });

        setTimeout(() => {
            chrome.notifications.clear(notificationId);
        }, 5000);
    } catch (error) {
        console.log('Sync notification error:', error);
    }
}

// ================================
// HELPERS
// ================================
function getCategoryIcon(storeName) {
    const store = (storeName || '').toLowerCase();
    if (store.includes('amazon') || store.includes('daraz')) return '📦';
    if (store.includes('netflix') || store.includes('hulu') || store.includes('disney')) return '📺';
    if (store.includes('spotify') || store.includes('apple music')) return '🎵';
    if (store.includes('uber') || store.includes('doordash') || store.includes('foodpanda')) return '🍔';
    if (store.includes('nike') || store.includes('adidas')) return '👕';
    if (store.includes('apple') || store.includes('best buy')) return '📱';
    return '🛍️';
}

function getCategoryFromStore(storeName) {
    const store = (storeName || '').toLowerCase();
    if (store.includes('food') || store.includes('restaurant') || store.includes('foodpanda')) return 'Food & Dining';
    if (store.includes('amazon') || store.includes('daraz') || store.includes('shopping')) return 'Shopping';
    if (store.includes('netflix') || store.includes('spotify')) return 'Entertainment';
    if (store.includes('uber') || store.includes('careem')) return 'Transport';
    return 'Shopping';
}

// ================================
// DARK PATTERN PROTECTION
// ================================
async function handleDarkPatternDetected(data) {
    console.log('🛡️ Dark pattern detected:', data);

    // Store detection for statistics
    const statsKey = 'vt_dark_pattern_stats';
    const storage = await chrome.storage.local.get([statsKey]);
    const stats = storage[statsKey] || {
        totalDetected: 0,
        totalBlocked: 0,
        totalSaved: 0,
        detections: [],
        lastUpdated: null
    };

    stats.totalDetected++;
    stats.detections.unshift({
        url: data.hostname,
        patterns: data.patterns,
        priceInfo: data.priceInfo,
        date: new Date().toISOString()
    });

    // Keep only last 50 detections
    stats.detections = stats.detections.slice(0, 50);
    stats.lastUpdated = new Date().toISOString();

    await chrome.storage.local.set({ [statsKey]: stats });

    // Show notification for critical patterns
    const hasCritical = data.patterns.some(p => p.severity === 'CRITICAL');
    if (hasCritical) {
        showDarkPatternNotification(data);
    }
}

function showDarkPatternNotification(data) {
    const notificationId = `dark-pattern-${Date.now()}`;

    try {
        chrome.notifications.create(notificationId, {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: '🛡️ Hidden Charge Detected!',
            message: `Watch out! ${data.hostname} may have sneaky subscription tactics.`,
            priority: 2
        });

        setTimeout(() => {
            chrome.notifications.clear(notificationId);
        }, 8000);
    } catch (error) {
        console.log('Dark pattern notification error:', error);
    }
}

async function setTrialReminder(data, sendResponse) {
    try {
        console.log('📝 Setting trial reminder:', data);

        // Save reminder data
        const remindersKey = 'vt_trial_reminders';
        const storage = await chrome.storage.local.get([remindersKey]);
        const reminders = storage[remindersKey] || [];

        reminders.push(data);
        await chrome.storage.local.set({ [remindersKey]: reminders });

        // Create alarm for reminder
        const reminderDate = new Date(data.reminderDate);
        const alarmName = `trial_reminder_${data.id}`;

        chrome.alarms.create(alarmName, {
            when: reminderDate.getTime()
        });

        console.log('✅ Reminder set for:', reminderDate);

        // Update stats
        const statsKey = 'vt_dark_pattern_stats';
        const statsStorage = await chrome.storage.local.get([statsKey]);
        const stats = statsStorage[statsKey] || {
            totalDetected: 0,
            totalBlocked: 0,
            totalSaved: 0,
            detections: [],
            lastUpdated: null
        };

        stats.totalBlocked++;
        if (data.monthlyPrice) {
            stats.totalSaved += data.monthlyPrice * 12;
        }
        stats.lastUpdated = new Date().toISOString();

        await chrome.storage.local.set({ [statsKey]: stats });

        sendResponse({ success: true, reminder: data });
    } catch (error) {
        console.error('Set reminder error:', error);
        sendResponse({ success: false, error: error.message });
    }
}

async function getProtectionStats(sendResponse) {
    try {
        const statsKey = 'vt_dark_pattern_stats';
        const remindersKey = 'vt_trial_reminders';

        const storage = await chrome.storage.local.get([statsKey, remindersKey]);
        const stats = storage[statsKey] || {
            totalDetected: 0,
            totalBlocked: 0,
            totalSaved: 0,
            detections: [],
            lastUpdated: null
        };

        const reminders = storage[remindersKey] || [];
        const activeReminders = reminders.filter(r => r.status === 'active');

        sendResponse({
            success: true,
            stats: {
                ...stats,
                activeReminders: activeReminders.length,
                upcomingTrials: activeReminders
            }
        });
    } catch (error) {
        sendResponse({ success: false, error: error.message });
    }
}

// Handle alarm triggers
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name.startsWith('trial_reminder_')) {
        const reminderId = alarm.name.replace('trial_reminder_', '');

        // Get reminder details
        const remindersKey = 'vt_trial_reminders';
        const storage = await chrome.storage.local.get([remindersKey]);
        const reminders = storage[remindersKey] || [];
        const reminder = reminders.find(r => r.id === reminderId);

        if (reminder) {
            // Show notification
            chrome.notifications.create(`trial-ending-${Date.now()}`, {
                type: 'basic',
                iconUrl: chrome.runtime.getURL('icons/logo.png'),
                title: '⏰ Trial Ending Soon!',
                message: `Your ${reminder.service} trial ends in 2 days! Cancel now to avoid ${reminder.currency} ${reminder.monthlyPrice}/month charge.`,
                priority: 2,
                requireInteraction: true
            });

            // Update reminder status
            reminder.status = 'notified';
            await chrome.storage.local.set({ [remindersKey]: reminders });
        }
    }
});

// ================================
// LIFECYCLE EVENTS
// ================================
chrome.runtime.onStartup.addListener(() => {
    console.log('🚀 Vibe Tracker extension started with Dark Pattern Protection');
});

chrome.runtime.onInstalled.addListener(() => {
    console.log('📦 Vibe Tracker extension installed');

    // Initialize dark pattern stats
    chrome.storage.local.get(['vt_dark_pattern_stats'], (result) => {
        if (!result.vt_dark_pattern_stats) {
            chrome.storage.local.set({
                vt_dark_pattern_stats: {
                    totalDetected: 0,
                    totalBlocked: 0,
                    totalSaved: 0,
                    detections: [],
                    lastUpdated: new Date().toISOString()
                }
            });
        }
    });

    // Show welcome notification
    try {
        chrome.notifications.create('welcome', {
            type: 'basic',
            iconUrl: chrome.runtime.getURL('icons/logo.png'),
            title: '💸 Vibe Tracker Installed!',
            message: 'Now with Dark Pattern Protection! Stay safe from sneaky subscriptions 🛡️',
            priority: 2
        });
    } catch (error) {
        console.log('Welcome notification error:', error);
    }
});

// Periodic sync check (every 5 minutes)
setInterval(() => {
    syncPendingTransactions();
}, 5 * 60 * 1000);

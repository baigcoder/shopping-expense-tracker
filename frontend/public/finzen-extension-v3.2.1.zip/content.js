// Universal Content Script - ENHANCED DYNAMIC Detection & Tracking
// v3.2.1 - Highly accurate multi-signal detection
(function () {
    'use strict';

    console.log('💸 Vibe Tracker: Enhanced smart detection loaded');

    // Prevent duplicate detection
    if (window.__vibeTrackerLoaded) return;
    window.__vibeTrackerLoaded = true;

    // ================================
    // SERVICE-SPECIFIC DETECTION
    // ================================

    // Known services and their specific confirmation patterns
    const SERVICE_PATTERNS = {
        // Cloud Storage
        'dropbox.com': {
            confirmUrls: [/onboarding/i, /welcome/i, /use-case/i, /getting-started/i],
            confirmText: ['welcome to dropbox', 'what do you think', 'personal', 'work'],
            trialIndicators: ['professional', 'plus', 'business']
        },
        'drive.google.com': {
            confirmUrls: [/welcome/i, /quota/i],
            confirmText: ['storage', 'upgrade complete'],
            trialIndicators: ['google one']
        },
        'icloud.com': {
            confirmUrls: [/welcome/i],
            confirmText: ['icloud+', 'storage plan'],
            trialIndicators: ['trial']
        },

        // Streaming
        'netflix.com': {
            confirmUrls: [/browse/i, /welcome/i, /signup\/planform/i],
            confirmText: ['welcome back', 'start watching', 'your membership'],
            trialIndicators: ['free month']
        },
        'spotify.com': {
            confirmUrls: [/premium/i, /checkout\/success/i],
            confirmText: ['welcome to premium', 'your premium'],
            trialIndicators: ['free trial', 'trial period']
        },
        'disneyplus.com': {
            confirmUrls: [/welcome/i, /begin/i],
            confirmText: ['start streaming', 'disney+'],
            trialIndicators: ['trial']
        },
        'hulu.com': {
            confirmUrls: [/welcome/i],
            confirmText: ['start watching'],
            trialIndicators: ['free trial']
        },
        'primevideo.com': {
            confirmUrls: [/gp\/video/i],
            confirmText: ['prime video'],
            trialIndicators: ['trial']
        },

        // Productivity
        'notion.so': {
            confirmUrls: [/onboarding/i, /welcome/i],
            confirmText: ['welcome to notion', 'get started'],
            trialIndicators: ['plus', 'business', 'trial']
        },
        'slack.com': {
            confirmUrls: [/getting-started/i],
            confirmText: ['welcome to slack'],
            trialIndicators: ['pro', 'business+']
        },
        'figma.com': {
            confirmUrls: [/files/i],
            confirmText: ['welcome to figma'],
            trialIndicators: ['professional', 'organization']
        },
        'canva.com': {
            confirmUrls: [/design/i, /create/i],
            confirmText: ['canva pro'],
            trialIndicators: ['trial', 'pro trial']
        },

        // Development
        'github.com': {
            confirmUrls: [/settings\/billing/i],
            confirmText: ['thank you for upgrading', 'copilot'],
            trialIndicators: ['trial', 'pro']
        },
        'vercel.com': {
            confirmUrls: [/dashboard/i, /billing/i],
            confirmText: ['upgraded to pro'],
            trialIndicators: ['pro', 'enterprise']
        },

        // E-commerce
        'amazon.com': {
            confirmUrls: [/thankyou/i, /order-details/i, /confirmation/i],
            confirmText: ['order placed', 'delivery', 'arriving'],
            trialIndicators: ['prime trial']
        },
        'ebay.com': {
            confirmUrls: [/confirmation/i],
            confirmText: ['you bought', 'order confirmed'],
            trialIndicators: []
        },

        // Microsoft
        'microsoft.com': {
            confirmUrls: [/thankyou/i, /confirmation/i, /account/i],
            confirmText: ['thank you', 'subscription', '365'],
            trialIndicators: ['trial', 'free month']
        },
        'office.com': {
            confirmUrls: [/landing/i],
            confirmText: ['microsoft 365', 'office'],
            trialIndicators: ['trial']
        },

        // Adobe
        'adobe.com': {
            confirmUrls: [/thankyou/i, /plans/i],
            confirmText: ['creative cloud', 'thank you'],
            trialIndicators: ['trial', '7 days']
        },

        // Education
        'coursera.org': {
            confirmUrls: [/learn/i, /my-purchases/i],
            confirmText: ['enrolled', 'subscription active'],
            trialIndicators: ['7-day', 'trial']
        },
        'udemy.com': {
            confirmUrls: [/cart\/success/i],
            confirmText: ['thank you for your purchase'],
            trialIndicators: []
        }
    };

    // ================================
    // CREDIT CARD FORM DETECTION
    // ================================

    const CREDIT_CARD_SELECTORS = [
        'input[name*="card"]', 'input[name*="credit"]',
        'input[autocomplete="cc-number"]', 'input[autocomplete="cc-name"]',
        'input[autocomplete="cc-exp"]', 'input[autocomplete="cc-csc"]',
        'input[placeholder*="card"]', 'input[placeholder*="4242"]',
        '[class*="card-number"]', '[class*="credit-card"]',
        '[data-stripe]', '[class*="stripe"]',
        'iframe[src*="stripe"]', 'iframe[src*="paypal"]',
        'iframe[src*="braintree"]', 'iframe[src*="checkout"]'
    ];

    // ================================
    // URL PATTERNS
    // ================================

    const SUCCESS_URL_PATTERNS = [
        // Generic success indicators
        /\/success/i, /\/confirm/i, /\/thank/i, /\/complete/i,
        /\/receipt/i, /\/order/i, /\/welcome/i, /\/onboarding/i,
        /\/activated/i, /\/subscribed/i, /\?success/i, /\?confirmed/i,
        /\?status=success/i, /\?payment=complete/i,

        // Specific platforms
        /flow=individual/i, /use-case/i, /getting-started/i,
        /checkout\/success/i, /payment\/success/i,
        /subscribe\/confirm/i, /billing\/thankyou/i,
        /order-confirmation/i, /purchase-complete/i,

        // Post-action URLs
        /after-signup/i, /post-checkout/i, /account-created/i
    ];

    // ================================
    // DOM SUCCESS ELEMENTS
    // ================================

    const SUCCESS_ELEMENT_SELECTORS = [
        // Class-based
        '[class*="success"]', '[class*="confirm"]', '[class*="thank"]',
        '[class*="complete"]', '[class*="receipt"]', '[class*="order-"]',
        '[class*="welcome"]', '[class*="activated"]', '[class*="enrolled"]',

        // ID-based
        '[id*="success"]', '[id*="confirm"]', '[id*="thank"]',
        '[id*="complete"]', '[id*="receipt"]',

        // Common UI elements
        '.checkmark', '.tick', '.done', '.completed',
        '[data-testid*="success"]', '[data-testid*="confirm"]',

        // SVG checkmarks (common in modern UIs)
        'svg.checkmark', 'svg[class*="check"]', 'svg[class*="success"]',
        '.fa-check-circle', '.fa-check', '[class*="icon-check"]'
    ];

    // ================================
    // CURRENCY DETECTION (Enhanced)
    // ================================

    const CURRENCY_PATTERNS = [
        /\$\s*([\d,]+\.?\d*)/g,
        /USD\s*([\d,]+\.?\d*)/gi,
        /US\$\s*([\d,]+\.?\d*)/gi,
        /€\s*([\d,]+\.?\d*)/g,
        /EUR\s*([\d,]+\.?\d*)/gi,
        /£\s*([\d,]+\.?\d*)/g,
        /GBP\s*([\d,]+\.?\d*)/gi,
        /₹\s*([\d,]+\.?\d*)/g,
        /INR\s*([\d,]+\.?\d*)/gi,
        /Rs\.?\s*([\d,]+\.?\d*)/gi,
        /PKR\s*([\d,]+\.?\d*)/gi,
        /¥\s*([\d,]+\.?\d*)/g,
        /JPY\s*([\d,]+\.?\d*)/gi,
        /CAD\s*([\d,]+\.?\d*)/gi,
        /AUD\s*([\d,]+\.?\d*)/gi,
        /([\d,]+\.?\d*)\s*\/\s*mo(?:nth)?/gi,
        /([\d,]+\.?\d*)\s*per\s*month/gi,
        /([\d,]+\.?\d*)\s*\/\s*year/gi,
        /billed\s*([\d,]+\.?\d*)/gi
    ];

    // ================================
    // TRIAL PATTERNS (Enhanced)
    // ================================

    const TRIAL_PATTERNS = [
        /(\d+)\s*[-–]?\s*day\s*(free\s*)?trial/i,
        /free\s*for\s*(\d+)\s*days?/i,
        /trial\s*ends?\s*(on|in)\s*(\d+)/i,
        /(\d+)\s*days?\s*free/i,
        /free\s*trial/i,
        /start.*trial/i,
        /trial\s*period/i,
        /trial\s*started/i,
        /trial\s*active/i,
        /your\s*trial/i,
        /trial\s*ends?\s*on\s*\w+\s*\d+/i
    ];

    // ================================
    // STATE MANAGEMENT
    // ================================

    let hasDetectedOnThisPage = false;
    let lastUrl = window.location.href;
    let formSubmitPending = false;
    let creditCardFormSeen = false;
    let lastCreditCardPage = '';

    // ================================
    // UTILITY FUNCTIONS
    // ================================

    function getPageText() {
        return document.body ? document.body.innerText.toLowerCase() : '';
    }

    function getHostname() {
        return window.location.hostname.replace('www.', '');
    }

    function matchesHost(hostname) {
        const current = getHostname();
        return current === hostname || current.endsWith('.' + hostname);
    }

    function getBrandName() {
        const hostname = getHostname();

        // Check known services first
        for (const service of Object.keys(SERVICE_PATTERNS)) {
            if (matchesHost(service)) {
                return service.split('.')[0].charAt(0).toUpperCase() + service.split('.')[0].slice(1);
            }
        }

        // Meta tags
        const ogSiteName = document.querySelector('meta[property="og:site_name"]');
        if (ogSiteName?.content) return ogSiteName.content;

        const appName = document.querySelector('meta[name="application-name"]');
        if (appName?.content) return appName.content;

        // Title parsing
        const title = document.title;
        if (title) {
            const separators = ['|', ' - ', ' – ', ' — '];
            for (const sep of separators) {
                if (title.includes(sep)) {
                    const parts = title.split(sep);
                    const brand = parts[parts.length - 1].trim();
                    if (brand.length > 2 && brand.length < 30) return brand;
                }
            }
        }

        // Fallback to hostname
        const parts = hostname.split('.');
        return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
    }

    function extractPrices(text) {
        const prices = [];
        for (const pattern of CURRENCY_PATTERNS) {
            pattern.lastIndex = 0;
            let match;
            while ((match = pattern.exec(text)) !== null) {
                const price = parseFloat(match[1].replace(/,/g, ''));
                if (price > 0 && price < 50000) prices.push(price);
            }
        }
        return [...new Set(prices)].sort((a, b) => b - a);
    }

    function extractTrialDays(text) {
        for (const pattern of TRIAL_PATTERNS) {
            const match = text.match(pattern);
            if (match && match[1]) return parseInt(match[1], 10);
        }
        // Check for specific day mentions
        const dayMatch = text.match(/(\d+)\s*day/i);
        if (dayMatch && parseInt(dayMatch[1]) <= 90) return parseInt(dayMatch[1]);
        return 0;
    }

    function guessCategory(name, hostname) {
        const text = (name + ' ' + hostname).toLowerCase();
        if (/netflix|hulu|disney|hbo|prime|youtube|spotify|stream|video|music|twitch/i.test(text)) return 'Entertainment';
        if (/adobe|figma|canva|photoshop|creative|design|sketch/i.test(text)) return 'Creative';
        if (/notion|slack|trello|asana|productivity|monday|clickup/i.test(text)) return 'Productivity';
        if (/github|vercel|netlify|aws|dev|hosting|heroku|digital.*ocean/i.test(text)) return 'Development';
        if (/dropbox|google|icloud|storage|drive|box\.com/i.test(text)) return 'Storage';
        if (/grammarly|coursera|udemy|learn|skillshare|masterclass/i.test(text)) return 'Education';
        if (/amazon|ebay|shop|store|daraz|walmart|target|aliexpress/i.test(text)) return 'Shopping';
        if (/food|uber.*eat|deliveroo|restaurant|doordash|grubhub/i.test(text)) return 'Food';
        if (/microsoft|office|365/i.test(text)) return 'Productivity';
        return 'Other';
    }

    // ================================
    // DETECTION METHODS
    // ================================

    // Method 1: Service-Specific Detection
    function checkServiceSpecific() {
        const hostname = getHostname();
        const text = getPageText();
        const url = window.location.href.toLowerCase();

        for (const [service, patterns] of Object.entries(SERVICE_PATTERNS)) {
            if (!matchesHost(service)) continue;

            // Check URL patterns
            const urlMatch = patterns.confirmUrls.some(p => p.test(url));

            // Check text patterns
            const textMatch = patterns.confirmText.some(t => text.includes(t.toLowerCase()));

            // Check trial indicators
            const hasTrial = patterns.trialIndicators.some(t => text.includes(t.toLowerCase()));

            if (urlMatch && textMatch) {
                console.log('💸 Service-specific match:', service, { urlMatch, textMatch, hasTrial });
                return { matched: true, service, hasTrial };
            }
        }
        return { matched: false };
    }

    // Method 2: Credit Card Form Detection (tracks if user was on payment page)
    function checkCreditCardForms() {
        for (const selector of CREDIT_CARD_SELECTORS) {
            try {
                if (document.querySelector(selector)) {
                    creditCardFormSeen = true;
                    lastCreditCardPage = window.location.href;
                    console.log('💸 Credit card form detected');
                    return true;
                }
            } catch (e) { /* ignore */ }
        }
        return false;
    }

    function wasOnCreditCardPage() {
        return creditCardFormSeen && lastCreditCardPage !== window.location.href;
    }

    // Method 3: URL Pattern Detection
    function checkUrlPattern() {
        const url = window.location.href.toLowerCase();
        return SUCCESS_URL_PATTERNS.some(pattern => pattern.test(url));
    }

    // Method 4: DOM Success Elements Detection
    function checkSuccessElements() {
        for (const selector of SUCCESS_ELEMENT_SELECTORS) {
            try {
                const elements = document.querySelectorAll(selector);
                if (elements.length > 0) {
                    for (const el of elements) {
                        const rect = el.getBoundingClientRect();
                        if (rect.width > 0 && rect.height > 0) {
                            console.log('💸 Found success element:', selector);
                            return true;
                        }
                    }
                }
            } catch (e) { /* ignore selector errors */ }
        }
        return false;
    }

    // Method 5: Enhanced Semantic Content Analysis
    function analyzePageContent() {
        const text = getPageText();
        const prices = extractPrices(document.body?.innerText || '');

        const signals = {
            // Positive signals
            hasPrice: prices.length > 0,
            hasTrial: TRIAL_PATTERNS.some(p => p.test(text)),
            hasWelcome: /welcome|congratulations|you're.*all.*set|thank\s*you/i.test(text),
            hasConfirmation: /confirmed|successful|complete|activated|started|enrolled|subscribed/i.test(text),
            hasOrderInfo: /order|receipt|confirmation|transaction|invoice|billing/i.test(text),
            hasCheckmark: document.querySelector('svg[class*="check"], .checkmark, .tick, [class*="success-icon"], .fa-check') !== null,
            hasPositiveTone: /enjoy|ready|active|enabled|unlocked/i.test(text),

            // Negative signals (marketing pages)
            hasSignupCTA: /sign\s*up|create\s*account|start\s*free|get\s*started|join\s*now/i.test(text),
            hasPricingPage: /pricing|plans|choose.*plan|compare.*plans|select.*plan/i.test(text),
            hasAddToCart: /add\s*to\s*cart|buy\s*now|subscribe\s*now|checkout/i.test(text),
            hasLoginForm: document.querySelector('input[type="password"]:not([autocomplete="cc-csc"])') !== null &&
                document.querySelector('input[type="email"], input[type="text"][name*="email"]') !== null
        };

        // Weighted scoring
        let score = 0;
        if (signals.hasWelcome) score += 4;
        if (signals.hasConfirmation) score += 5;
        if (signals.hasOrderInfo) score += 3;
        if (signals.hasCheckmark) score += 4;
        if (signals.hasPositiveTone) score += 2;
        if (signals.hasPrice) score += 1;
        if (signals.hasTrial) score += 3;

        // Negative scoring
        if (signals.hasSignupCTA) score -= 3;
        if (signals.hasPricingPage) score -= 5;
        if (signals.hasAddToCart) score -= 4;
        if (signals.hasLoginForm) score -= 3;

        // Boost if came from credit card page
        if (wasOnCreditCardPage()) score += 4;

        console.log('💸 Content analysis:', { signals, score, prices: prices.slice(0, 3) });
        return { passed: score >= 5, score, signals };
    }

    // ================================
    // MAIN DETECTION LOGIC
    // ================================

    function shouldTriggerDetection() {
        // First check credit card forms (for tracking)
        checkCreditCardForms();

        // Run all detection methods
        const serviceMatch = checkServiceSpecific();
        const urlMatch = checkUrlPattern();
        const successElements = checkSuccessElements();
        const contentAnalysis = analyzePageContent();
        const afterFormSubmit = formSubmitPending;
        const afterCreditCard = wasOnCreditCardPage();

        console.log('💸 Detection signals:', {
            serviceMatch: serviceMatch.matched,
            urlMatch,
            successElements,
            contentScore: contentAnalysis.score,
            afterFormSubmit,
            afterCreditCard
        });

        // Decision matrix (prioritized)

        // 1. Service-specific match is highest confidence
        if (serviceMatch.matched) return true;

        // 2. URL pattern + content analysis
        if (urlMatch && contentAnalysis.passed) return true;

        // 3. After credit card page + any positive signal
        if (afterCreditCard && (urlMatch || successElements || contentAnalysis.score >= 3)) return true;

        // 4. After form submit + positive signals
        if (afterFormSubmit && (urlMatch || successElements || contentAnalysis.passed)) return true;

        // 5. Success elements + good content score
        if (successElements && contentAnalysis.score >= 4) return true;

        // 6. Very high content score alone
        if (contentAnalysis.score >= 8) return true;

        return false;
    }

    // ================================
    // TRANSACTION EXTRACTION
    // ================================

    function extractTransactionData() {
        const pageText = getPageText();
        const brandName = getBrandName();
        const hostname = getHostname();
        const prices = extractPrices(document.body?.innerText || '');
        const trialDays = extractTrialDays(pageText);

        // Determine transaction type
        let type = 'purchase';
        let label = 'Purchase';
        let icon = '🛒';

        const isTrial = trialDays > 0 || /trial|free.*period/i.test(pageText);
        const isSubscription = /subscription|membership|recurring|billed|monthly|yearly|annual/i.test(pageText);

        if (isTrial) {
            type = 'trial';
            label = 'Trial Started';
            icon = '🎁';
        } else if (isSubscription) {
            type = 'subscription';
            label = 'Subscription';
            icon = '💳';
        }

        // Detect billing cycle
        let billingCycle = 'monthly';
        if (/\/year|per year|yearly|annual|billed annually/i.test(pageText)) billingCycle = 'yearly';
        if (/\/week|per week|weekly/i.test(pageText)) billingCycle = 'weekly';

        // Calculate renewal date
        let renewalDate = null;
        if (type !== 'purchase') {
            const now = new Date();
            if (isTrial && trialDays > 0) {
                now.setDate(now.getDate() + trialDays);
            } else if (billingCycle === 'yearly') {
                now.setFullYear(now.getFullYear() + 1);
            } else if (billingCycle === 'weekly') {
                now.setDate(now.getDate() + 7);
            } else {
                now.setMonth(now.getMonth() + 1);
            }
            renewalDate = now.toISOString();
        }

        return {
            name: brandName,
            hostname: hostname,
            type: type,
            label: label,
            icon: icon,
            price: prices[0] || 0,
            amount: prices[0] || 0,
            isTrial: isTrial,
            trialDays: trialDays || (isTrial ? 7 : 0),
            category: guessCategory(brandName, hostname),
            billingCycle: billingCycle,
            renewalDate: renewalDate,
            sourceUrl: window.location.href,
            detectedAt: new Date().toISOString(),
            autoAddTransaction: true
        };
    }

    // ================================
    // NOTIFICATION & SAVE
    // ================================

    function showDetectionNotification(data) {
        const existing = document.getElementById('vibe-tracker-notification');
        if (existing) existing.remove();

        const notification = document.createElement('div');
        notification.id = 'vibe-tracker-notification';
        notification.innerHTML = `
            <div style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
                color: white;
                padding: 16px 20px;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                z-index: 2147483647;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                max-width: 320px;
                animation: vibeSlideIn 0.3s ease-out;
                border: 2px solid rgba(255,255,255,0.3);
            ">
                <style>
                    @keyframes vibeSlideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
                </style>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 28px;">${data.icon}</span>
                    <div style="flex: 1;">
                        <div style="font-weight: 700; font-size: 14px; margin-bottom: 2px;">💸 Vibe Tracker</div>
                        <div style="font-size: 13px; font-weight: 600;">${data.name}</div>
                        <div style="font-size: 12px; opacity: 0.9;">${data.label} ${data.amount > 0 ? '• $' + data.amount.toFixed(2) : ''}</div>
                        ${data.isTrial ? `<div style="font-size: 11px; opacity: 0.8; margin-top: 2px;">${data.trialDays} day free trial</div>` : ''}
                    </div>
                    <button onclick="this.closest('#vibe-tracker-notification').remove()" style="
                        background: rgba(255,255,255,0.2);
                        border: none;
                        color: white;
                        width: 24px;
                        height: 24px;
                        border-radius: 50%;
                        cursor: pointer;
                        font-size: 16px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">×</button>
                </div>
            </div>
        `;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 10000);
    }

    function saveTransaction(data) {
        console.log('💸 Saving transaction:', data);

        // Send to background script
        chrome.runtime.sendMessage({
            type: 'PURCHASE_DETECTED',
            data: data
        }).then(response => {
            console.log('💸 Save response:', response);
        }).catch(err => {
            console.log('💸 Save error (may be logged out):', err);
        });

        // Also send as subscription for trials
        if (data.isTrial || data.type === 'subscription') {
            chrome.runtime.sendMessage({
                type: 'SUBSCRIPTION_DETECTED',
                data: {
                    name: data.name,
                    price: data.price,
                    amount: data.price,
                    billing_cycle: data.billingCycle,
                    is_trial: data.isTrial,
                    trial_days: data.trialDays,
                    category: data.category,
                    source_url: data.sourceUrl,
                    hostname: data.hostname,
                    renewal_date: data.renewalDate
                }
            }).catch(() => { });
        }
    }

    // ================================
    // MAIN DETECTION RUNNER
    // ================================

    function runDetection() {
        if (hasDetectedOnThisPage) {
            console.log('💸 Already detected on this page');
            return;
        }

        // Check session storage to prevent duplicate detection
        const trackKey = `vibe_tracked_${window.location.pathname}`;
        if (sessionStorage.getItem(trackKey)) {
            console.log('💸 Already tracked this session');
            return;
        }

        if (shouldTriggerDetection()) {
            console.log('💸 🎉 TRANSACTION DETECTED!');
            hasDetectedOnThisPage = true;
            sessionStorage.setItem(trackKey, 'true');

            const data = extractTransactionData();
            showDetectionNotification(data);
            saveTransaction(data);
        }
    }

    // ================================
    // EVENT LISTENERS & OBSERVERS
    // ================================

    // Form submission interception
    document.addEventListener('submit', (e) => {
        const form = e.target;
        const action = (form.action || '').toLowerCase();
        const formHTML = form.innerHTML.toLowerCase();

        if (/checkout|payment|subscribe|purchase|billing|order/i.test(action + formHTML)) {
            console.log('💸 Payment form submitted, will check after navigation');
            formSubmitPending = true;
            setTimeout(() => { formSubmitPending = false; }, 15000);
        }
    }, true);

    // Click interception for button-based checkouts
    document.addEventListener('click', (e) => {
        const target = e.target.closest('button, [role="button"], a');
        if (!target) return;

        const text = (target.innerText || '').toLowerCase();
        const className = (target.className || '').toLowerCase();

        if (/submit|pay|confirm|complete|checkout|subscribe|place.*order/i.test(text + className)) {
            console.log('💸 Payment button clicked');
            formSubmitPending = true;
            setTimeout(() => { formSubmitPending = false; }, 15000);
        }
    }, true);

    // URL change detection (for SPAs)
    const urlObserver = new MutationObserver(() => {
        if (window.location.href !== lastUrl) {
            console.log('💸 URL changed:', lastUrl, '->', window.location.href);
            lastUrl = window.location.href;
            hasDetectedOnThisPage = false;
            setTimeout(runDetection, 1000);
        }
    });

    // DOM mutation observer
    const domObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === 1) {
                    const el = node;
                    const classes = (el.className || '').toLowerCase();
                    const id = (el.id || '').toLowerCase();

                    if (/success|confirm|thank|complete|receipt|welcome/i.test(classes + id)) {
                        console.log('💸 Success element added via mutation');
                        setTimeout(runDetection, 500);
                        return;
                    }
                }
            }
        }
    });

    // History API interception (for SPAs)
    const originalPushState = history.pushState;
    history.pushState = function () {
        originalPushState.apply(this, arguments);
        console.log('💸 pushState detected');
        hasDetectedOnThisPage = false;
        setTimeout(runDetection, 1000);
    };

    const originalReplaceState = history.replaceState;
    history.replaceState = function () {
        originalReplaceState.apply(this, arguments);
        console.log('💸 replaceState detected');
        hasDetectedOnThisPage = false;
        setTimeout(runDetection, 1000);
    };

    window.addEventListener('popstate', () => {
        console.log('💸 popstate detected');
        hasDetectedOnThisPage = false;
        setTimeout(runDetection, 1000);
    });

    // ================================
    // INITIALIZATION
    // ================================

    function init() {
        if (document.body) {
            urlObserver.observe(document.body, { childList: true, subtree: true });
            domObserver.observe(document.body, { childList: true, subtree: true });
        }

        // Check for credit card forms on load
        checkCreditCardForms();

        // Initial detection
        if (document.readyState === 'complete') {
            setTimeout(runDetection, 1000);
        } else {
            window.addEventListener('load', () => setTimeout(runDetection, 1000));
        }

        // Delayed checks for slow-loading pages
        setTimeout(runDetection, 3000);
        setTimeout(runDetection, 6000);
    }

    if (document.body) {
        init();
    } else {
        document.addEventListener('DOMContentLoaded', init);
    }

    console.log('💸 Vibe Tracker: Enhanced detection ready (v3.2.1)');

})();
